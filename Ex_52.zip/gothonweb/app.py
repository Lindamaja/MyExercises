from flask import Flask, session, request
from flask import url_for, redirect, render_template
import pickle
from hashlib import sha512
import map
import getpass

#password = getpass.getpass()
#print(password)

app = Flask(__name__)

salt = "46%.=d/Fas8d$"

@app.route('/', methods = ['GET'])
def check_user():
    if 'user' in session:
        return redirect(url_for('index'))
    else:
        return redirect(url_for('login'))

@app.route('/register', methods=['GET'])
def register():
    return render_template('register.html', background = "register")

@app.route('/register', methods=['POST'])
def mk_newUser():
    user = request.form.get('username')
    password = sha512( (request.form.get('password'))+salt ).hexdigest() # Encrypt the stored password with an algorithm from the
    # hashlib library. Md5 is the least recommended encryption algorithm. There are so called
    # "rainbow tables" available, dictionaries to reverse hashes to plaintext.

    data = {user:password}
    # Implement a check for already existing username before storing the username/password.
    # Otherwise the old password will be overwritten!!!
    # Below code only handles a non-existing or empty file.
    try:
        with open('u_list.txt', 'r+') as f:
            users = pickle.loads(f.read())
            print users
            f.seek(0)
            f.truncate()
            users.update(data)
            pickle.dump(users,f)
            return render_template('register.html', message = "Registration successful.", background = "register")
    except:
        with open('u_list.txt', 'w+') as f:
            pickle.dump(data,f)
            return render_template('register.html', message = "Registration successful.", background = "register")

@app.route('/login', methods = ['GET'])
def login():
    if 'user' in session:
        return redirect(url_for('start'))
    else:
        return render_template('login.html', background = "login")

@app.route('/login', methods = ['POST'])
def userdata():
    users = []
    username = request.form.get('username')
    password = request.form.get('password')
    with open('u_list.txt', 'r') as f:
        users = pickle.loads(f.read())
        print users #use this only for debugging
    try:
        users[username]
    except KeyError:
        return render_template('login.html', message = 'no such user')
    else:
        if users[username] == sha512(password+salt).hexdigest(): #apply the same encryption to the input and compare the two hashes
            session['user'] = username
            return redirect(url_for('index'))
        else:
            return render_template('login.html', message = 'wrong password')

@app.route('/logout', methods = ['GET'])
def logout():
    if 'user' in session:
        del session['user']
        return render_template('logged_out.html')

@app.route('/save', methods = ['GET'])
def save():
    if 'user' in session:
        thescene = map.SCENES[session['scene']]
        data = {session['user']:thescene.urlname}
        saves = {}

        with open('user_saves.txt', 'r+') as f:
            try:
                saves = pickle.loads(f.read())
            except:
                pass
            saves.update(data)
            f.seek(0)
            f.truncate()
            pickle.dump(saves,f)

        return render_template('show_scene.html', scene = thescene, message="Game saved.", name = session['user'])
    else:
        return redirect(url_for('login'))

@app.route('/load', methods = ['GET'])
def load():
    #it could be possible that someone tries to load this site without being logged in
    #implement error handling for the case there is no user (compare with save function)
    thescene = map.SCENES[session['scene']]
    message='Nothing to load.'
    with open('user_saves.txt', 'r') as f:
        try:
            saves = pickle.loads(f.read())
            print 'usersaves: ', saves
            user = session['user']
            thescene = map.SCENES[saves[user]]
            session['scene']=thescene.urlname
            message = 'Previous game loaded.'
        except:
            pass
        return render_template('show_scene.html', scene = thescene, message = message , name = session['user'])

@app.route('/game', methods=['GET'])
def game_get():
	if 'scene' in session:
		thescene = map.SCENES[session['scene']]
		return render_template('show_scene.html', background=thescene.urlname, scene=thescene)
	else:
		# The user doesn't have a session...
		# What should your code do in response?
		return render_template('new_game.html', background = "new_game")

@app.route('/game', methods=['POST'])
def game_post():
	userinput = request.form.get('userinput')
	if 'scene' in session:
		currentscene = map.SCENES[session['scene']]
		if userinput is None or userinput == "":
			# Weird, a POST request to /game with no user input... what should your code do?
			return render_template('show_scene.html', background=currentscene.urlname, scene=currentscene, errormessage="You need to speak up")
		else:
			nextscene = currentscene.go(userinput)
			
			if currentscene.urlname == 'laser_weapon_armory' and nextscene.urlname == 'death':
				current_tries = session['laser_weapon_armory_tries'] -1 
				if current_tries == None:
					nextscene.urlname == 'death'
				if current_tries>0:
					session['laser_weapon_armory_tries'] = current_tries
					currentscene.urlname = 'laser_weapon_armory'
					return render_template('show_scene.html', background=currentscene.urlname, scene=currentscene, errormessage="That was not right. Try again. You have %d tries left." %current_tries)
			if nextscene is None:
				return render_template('show_scene.html', background=currentscene.urlname, scene=currentscene, errormessage="I don't know what that means")
			else:
				session['scene'] = nextscene.urlname
				return render_template('show_scene.html', background=nextscene.urlname, scene=nextscene)
	else:
		# There's no session, how could the user get here?
		# What should your code do in response?
		return render_template('new_game.html')

# This URL initializes the session with starting values
@app.route('/startgame')
def index():
	session['scene'] = map.START.urlname
	session['laser_weapon_armory_tries'] = 10
	return redirect(url_for('game_get')) # redirect the browser to the url for game_get

app.secret_key = 'replace this with your secret key'

if __name__ == "__main__":
	app.run()